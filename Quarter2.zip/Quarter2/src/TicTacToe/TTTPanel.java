package TicTacToe;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class TTTPanel extends JPanel {

    //TODO: 3. Declare a Board instance field.
    private Board board;

    public TTTPanel(int width, int height) {
        setSize(width, height);

        //TODO: 4. Initialize your Board instance field.
        board = new Board();
        setupMouse();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;

        //TODO: 5. Tell your board to draw itself.  Run, test, fix, repeat.
       board.drawBoard(g2);
       board.drawScore(g2);
    }

    public void setupMouse(){
        addMouseListener(new MouseListener() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (board.checkForWinner() == 1){
                    board.restart();
                    board.addOScore();
                    repaint();
                }
                else if (board.checkForWinner() == 2){
                    board.restart();
                    board.addXScore();
                    repaint();
                }
                else if (board.checkForWinner() == 3){
                    board.restart();
                    repaint();
                }
                else{
                    int x = e.getX();
                    int y = e.getY();

                    int row = y / (board.getSize());
                    int col = x / (board.getSize());

                    board.takeTurn(row, col);

                    //TODO: 7.  ^^^Uncomment that^^^. Tell your board to takeTurn at row, col.
                    //          Run, test, fix, repeat.
                    repaint();
                }

            }
            @Override
            public void mouseClicked(MouseEvent e) {}
            @Override
            public void mouseReleased(MouseEvent e) {}
            @Override
            public void mouseEntered(MouseEvent e) {}
            @Override
            public void mouseExited(MouseEvent e) {}
        });
    }

}