package Blackjack;
import java.util.*;

public class Deck {

    /*Instance Fields.
    You'll need to have an ArrayList of cards.
     */
    private ArrayList<Card> cards;

    /*constructor.
    Make sure to create an ArrayList object!
    Add all 52 cards to the ArrayList.
     */

    public Deck(){
        //1. set cards to a new ArrayList.
       cards = new ArrayList<>();
        //2. Create 52 cards - 4 suits, 13 of each suit...
        for (int r = 1; r<14; r++){
            for(int s = 0; s < 4; s++){
                Card c = new Card(r,s);
                cards.add(c);
            }
        }
    }

    /*1. shuffle.  Randomizes the order of the cards.
        There are a few ways to do this.  See what you can come up with.
    */

    public void shuffle(){
        for(int i = 0; i < 100; i++){
            int a = (int)(Math.random()*(cards.size()-1));
            int b = (int)(Math.random()*(cards.size()-1));
            Card d = cards.get(a);
            cards.remove(d);
            cards.add(b, d);
        }
    }

    //2. dealCard().
    // Removes and returns the top card (from index 0) from the deck.
    public Card dealCard(){
        return cards.remove(0);
    }

    public boolean hasCards(){
        if(cards.size()>0)
            return true;
        return false;
    }

}