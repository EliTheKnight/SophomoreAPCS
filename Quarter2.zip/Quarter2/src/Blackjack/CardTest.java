package Blackjack;

public class CardTest {
    public static void main(String[] args) {
        //make a deck.
        Deck test = new Deck();

        test.shuffle();
        //print every card in the deck - make sure all 52 are there.
        while(test.hasCards() == true){
            Card a = test.dealCard();
            System.out.println(a.toString());
        }
        //shuffle the deck, print them all again, make sure they are randomized.
    }
}
