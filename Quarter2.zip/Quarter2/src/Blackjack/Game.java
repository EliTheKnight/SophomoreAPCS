package Blackjack;

import java.util.ArrayList;
import java.util.Scanner;

public class Game {

    /*3 Instance Fields.
    A deck of cards.
    The player should have an ArrayList<Card> to hold their hand of cards.
    The dealer should have an ArrayList<Card> to hold their hand of cards. */

    private Deck deck;
    private ArrayList<Card> player, dealer, hand1, hand2;
    private int playerSum, playerBet;
    private boolean split2;



    //Constructor.
    public Game() {
        this.deck = new Deck();
        this.player = new ArrayList<>();
        this.dealer = new ArrayList<>();
        this.hand1 = new ArrayList<>();
        this.hand2 = new ArrayList<>();
        this.playerSum = 1000;
        this.playerBet = playerBet;
        this.split2 = false;
    }

    /*Methods.  Details to follow.
        1. void dealCards()
        2. int scoreHand(ArrayList<Card> hand)
        3. int playerTurn()
        4. int dealerTurn()
        5. void playRound()
     */


    public void dealCards(){
        //TODO Shuffle the deck, deal each player 2 cards.

        deck.shuffle();
        player.add(deck.dealCard());
        dealer.add(deck.dealCard());
        player.add(deck.dealCard());
        dealer.add(deck.dealCard());
    }

    public int scoreHand(ArrayList<Card> hand){
        //add up the ranks of each card in the hand.
        //10's and face cards are worth 10.  (rank >= 10 -> 10 points)
        //Aces (rank 1) are worth 11.
        //Update an aceCount variable each time you find an Ace.
        int score = 0;
        int aceCount = 0;

        for (Card i: hand){
            if(i.getRank() > 10){
                score += 10;
            }
            else if (i.getRank() == 1){
                score += 11;
                aceCount ++;
            }
            else{
                score += i.getRank();
            }
        }

        //TODO While the score is over 21, if there are Aces worth 11, take 10 away
        //while(score > 21 && aceCount > 0)
        //so the ace is worth 1 instead of 11. (take 10 away from score, 1 away from aceCount
        while (score > 21 && aceCount > 0){
            aceCount--;
            score -= 10;
        }

        return score;
    }

    public void playerTurn(){
        Scanner input = new Scanner(System.in);
        if(player.get(0).getRank() == player.get(1).getRank() && playerBet*2 <= playerSum){
            System.out.println("Press 3 to split");
            if (input.nextInt() == 3){
                split2 = true;
                boolean stay = false;
                split();
                //1st split hand
                System.out.println("1st hand is " + hand1);
                System.out.println("1 for HIT, 2 for STAY.");
                while(scoreHand(hand1) < 21 && !stay){
                    int choose = input.nextInt();
                    if (choose == 2) {
                        System.out.println("Player stays.");
                        stay = true;
                    }else if (choose == 1){
                        //TODO: hit! deal a card from the deck to the player.
                        hand1.add(deck.dealCard());
                        printHand1();
                    }

                }
                //2nd split hand
                System.out.println("2nd hand is " + hand2);
                System.out.println("1 for HIT, 2 for STAY.");
                while(scoreHand(hand2) < 21){
                    int choose = input.nextInt();
                    if (choose == 2) {
                        System.out.println("Player stays.");
                        return;
                    }else if (choose == 1){
                        //TODO: hit! deal a card from the deck to the player.
                        hand2.add(deck.dealCard());
                        printHand2();
                    }

                }
                return;
            }
        }
        System.out.println("1 for HIT, 2 for STAY.");

        while(scoreHand(player) < 21) {
            int choice = input.nextInt();
            if (choice == 2) {
                System.out.println("Player stays.");
                return;
            }else if (choice == 1){
                //TODO: hit! deal a card from the deck to the player.
                player.add(deck.dealCard());
            }
            printState();
        }
    }

    public void dealerTurn(){
        //TODO: same as player except...
        //no user input.  The dealer keeps hitting until the score is 17 or more.
        //ie the dealer keeps hitting as long as the score is 16 or less.
        while (scoreHand(dealer) < 21) {
            if (scoreHand(dealer) >= 17) {
                System.out.println("Dealer stays.");
                printEndState();
                return;
            }
            else{
                System.out.println("dealer hits");
                dealer.add(deck.dealCard());
            }
            printEndState();
        }
        if (scoreHand(dealer) == 21){
            printEndState();
        }
    }

    public int playRound() {
        bet();
        dealCards();
        printState();

        //if player is dealt 21, game is over! Winner!
        if (scoreHand(player) == 21) {
            System.out.println("BLACKJACK!!!");
            return -1;    //note you can return; in a void method to exit the method immediately.
        }

        playerTurn();

        if(split2 == true){
            int partA = scoreSplit1();
            int partB = scoreSplit2();
            if(partA == 0){
            }
            if(partA == 1){
                winPlayerSum(getBet());
            }
            if(partA == 2){
                losePlayerSum(getBet());
            }
            if(partB == 0){
            }
            if(partB == 1){
                winPlayerSum(getBet());
            }
            if(partB == 2){
                losePlayerSum(getBet());
            }
            System.out.println(getPlayerSum());
            return 3;
        }

        if(scoreHand(player) > 21){
            System.out.println("You lose");
            return 2;
         }

        dealerTurn();

        if(scoreHand(dealer) > 21){
            System.out.println("YOU WIN");
            return 1;
        }

        //TODO if the player has more than the dealer, game over! Winner!
        //TODO if the dealer has more than the player, game over! Loser!
        //TODO if the dealer and the player have the same score, game over! Tie!
        if(scoreHand(player) > scoreHand(dealer)){
            System.out.println("YOU WIN");
            return 1;
        }
        if(scoreHand(dealer) > scoreHand(player)){
            System.out.println("You lose");
            return 2;
        }
        if(scoreHand(player) == scoreHand(dealer)){
            System.out.println("push");
            return 0;
        }
        return 0;
    }

    public void printState(){
        System.out.println();
        System.out.println("Dealer hand: " + dealer.get(0) + " *");
        System.out.println("Player hand: " + player);
    }

    public void printEndState(){
        if (split2 == true){
            System.out.println();
            System.out.println("Dealer hand: " + dealer);
            System.out.println("Player 1st hand: " + hand1);
            System.out.println("Player 2nd hand: " + hand2);
            return;
        }
        System.out.println();
        System.out.println("Dealer hand: " + dealer);
        System.out.println("Player hand: " + player);
    }

    public void printHand1(){
        System.out.println("Dealer hand: " + dealer.get(0) + " *");
        System.out.println("1st hand: " + hand1);
    }

    public void printHand2(){
        System.out.println("Dealer hand: " + dealer.get(0) + " *");
        System.out.println("2nd hand: " + hand2);
    }

    public int playAgain(){
        Scanner input = new Scanner(System.in);
        deck = new Deck();
        player = new ArrayList<>();
        dealer = new ArrayList<>();
        System.out.println("press 1 to play");

        if(input.nextInt() == 1) {
            return 1;
        }
        else{return 2;}
    }

    public int bet(){
        Scanner in = new Scanner(System.in);
        System.out.println("you have $" + playerSum);
        System.out.println("how much do you want to bet?");
        playerBet = in.nextInt();
        while (playerBet>playerSum || playerBet<=0){
            System.out.println("That is an invalid bet.");
            System.out.println("Please bet again.");
            playerBet = in.nextInt();
        }
        return playerBet;
    }

    public void split(){
        hand1.add(player.get(0));
        hand2.add(player.get(1));
        hand1.add(deck.dealCard());
        hand2.add(deck.dealCard());
    }

    public int scoreSplit1(){
        dealerTurn();

        if(scoreHand(hand1) > 21){
            System.out.println("You lose hand 1");
            return 2;
        }
        if(scoreHand(hand1) > 21){
            System.out.println("YOU WIN hand 1");
            return 1;
        }
        if(scoreHand(hand1) > scoreHand(dealer)){
            System.out.println("YOU WIN hand 1");
            return 1;
        }
        if(scoreHand(dealer) > scoreHand(hand1)){
            System.out.println("You lose hand 1");
            return 2;
        }
        if(scoreHand(hand1) == scoreHand(dealer)){
            System.out.println("push");
            return 0;
        }
        return 0;
    }

    public int scoreSplit2(){
        if(scoreHand(hand2) > 21){
            System.out.println("You lose hand 2");
            return 2;
        }
        if(scoreHand(dealer) > 21){
            System.out.println("YOU WIN hand 2");
            return 1;
        }
        if(scoreHand(hand2) > scoreHand(dealer)){
            System.out.println("YOU WIN hand 2");
            return 1;
        }
        if(scoreHand(dealer) > scoreHand(hand2)){
            System.out.println("You lose hand 2");
            return 2;
        }
        if(scoreHand(hand2) == scoreHand(dealer)){
            System.out.println("push");
            return 0;
        }
        return 0;
    }

    public int getPlayerSum(){
        return playerSum;
    }

    public void winPlayerSum(int bet){
        playerSum += bet;
    }

    public void blackjackPlayerSum(int bet){
        playerSum += (bet*1.5);
    }

    public void losePlayerSum(int bet){
        playerSum -= bet;
    }

    public int getBet(){
        return playerBet;
    }
}
