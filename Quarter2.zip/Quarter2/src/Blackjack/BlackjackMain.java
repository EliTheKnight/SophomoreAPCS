package Blackjack;

public class BlackjackMain {

    public static void main(String[] args) {
        Game theGame = new Game();
        while (theGame.getPlayerSum() > 0 && theGame.playAgain() == 1){
            int results = theGame.playRound();
            if (results == 0){
                System.out.println(theGame.getPlayerSum());
            }
            else if (results  == -1){
                theGame.blackjackPlayerSum(theGame.getBet());
                System.out.println(theGame.getPlayerSum());
            }
            else if (results  == 1){
                theGame.winPlayerSum(theGame.getBet());
                System.out.println(theGame.getPlayerSum());
            }
            else if (results == 2){
                theGame.losePlayerSum(theGame.getBet());
                System.out.println(theGame.getPlayerSum());
            }
            else{
            }
        }
        System.out.println("Thanks for playing!");

    }
}