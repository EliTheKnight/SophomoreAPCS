package Arrays;

public class ArrayPrimer {

    public static void main(String[] args) {

        //arrays                        arrayList
        //better syntax []              class, use methods to interact
        //locked size                   flexible - add, remove elements

        int[] arr = new int [5];
        //declare and initialize an array declare int[] var - arr, inits to a 5 element array - all 0

        int[] nums = {5,4,3,2,1}; //shortcut, static array initializer, can only be used on init.
        // indices -  0 1 2 3 4

        arr[2] = 20;
        System.out.println(arr[2]);
        System.out.println(arr); //this doesn't work, it prints the object array that just gives weird symbols
                                    //prints memory address of the array, pretty much useless information
        //loops with arrays:
        //sum all the values in nums, print the result
        int sum = 0;
        for (int i = 0; i < nums.length; i++){
            sum += nums[i];
        }
        System.out.println(sum);

        //THERE'S ANOTHER FOR LOOP!!!
        //these other for loops loop over each value in a collection (arrays and arrayLists)
        int sum2 = 0;
        for (int num: nums){    //for each int num in nums...
            sum2 += num;
        }
        System.out.println(sum2);

        //for-each loops are great when you just want to access values.
        //if you need to change an element, you MUST use a for-i loop.

        ArrayUtil.printArray(nums);
        System.out.println(ArrayUtil.getMaxIndex(nums));
        System.out.println(ArrayUtil.getMinIndex(nums));
        int[] randTest = ArrayUtil.getRandomArray(10,1,1000);
        ArrayUtil.printArray(randTest);

    }

}
