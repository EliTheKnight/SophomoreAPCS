package Arrays;

public class TwoDArrayQuestions {

    public static void main(String[] args) {


        //1. Declare a 4x4 2D array of integers.
        //   Using loops, make the contents of the array...
        //    0 0 0 0
        //    1 1 1 1
        //    2 2 2 2
        //    3 3 3 3

        int[][] mat = new int[4][4];

        for (int r = 0; r < mat.length; r++){
            for(int c = 0; c < mat[0].length; c++){
                mat[r][c] = r;
            }
        }

        //2.  Print the sum of each row in the 2D array

        for (int[] row: mat){
            ArrayUtil.printArray(row);
        }
        System.out.println();

        // 4 1 2 3
        // 0 4 2 3
        // 0 1 4 3
        // 0 1 2 4
        for (int r = 0; r < mat.length; r++){
            for(int c = 0; c < mat[0].length; c++){
                mat[r][c] = c;
                if (r == c)
                    mat[r][c] = 4;
            }
        }

        //2.  Print the sum of each row in the 2D array

        for (int[] row: mat){
            ArrayUtil.printArray(row);
        }

        //3. print the sum of each row.
        for (int r = 0; r < mat.length; r++){
            int sum = 0;
            for (int c = 0; c < mat[0].length; c++){
                sum += mat[r][c];
            }
            System.out.println(sum);
        }

    }
}
