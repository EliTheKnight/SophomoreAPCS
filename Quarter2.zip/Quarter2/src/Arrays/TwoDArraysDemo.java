package Arrays;

public class TwoDArraysDemo {

    public static void main(String[] args) {
        //What are 2D arrays?
        int[][] grid = {{1, 2, 3},  //array 0
                {4, 5, 6}}; //array 1
        System.out.println(grid[0][1]); //row 0 col 1
        System.out.println(grid[1][2]);

        int[][] mat = new int[3][2];
//        {{0, 0},
//         {0, 0}
//         {0, 0}}
        //How do we access the elements in a 2D array?
        for (int r = 0; r < mat.length; r++) {  //mat.length -> numRows
            for (int c = 0; c < mat[0].length; c++) {
                mat[r][c] = r * (c+1);
            }
        }
//        {{0, 0},
//         {1, 2}
//         {2, 4}}

        for(int[] row: mat){
            ArrayUtil.printArray(row);
        }
        for (int r = 0; r < mat.length; r++) {  //mat.length -> numRows
            for (int c = 0; c < mat[0].length; c++) {
                System.out.print(mat[r][c] + " ");
            }
            System.out.println();
        }

        //When should we use 2D arrays?
        //TicTacToe Chess Checkers
        //Gameboy Pokemon games -> map tiles 2D array!



    }
}
