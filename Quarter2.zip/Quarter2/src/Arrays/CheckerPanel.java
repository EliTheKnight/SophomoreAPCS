package Arrays;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class CheckerPanel extends JPanel {

    private int[][] board;

    public CheckerPanel(int width, int height) {
        setSize(width, height);

        board = new int[8][8];



        for(int r = 0; r < board.length; r++){
            for (int c = 0; c < board[0].length; c++){
                if ((c + r) % 2 == 0)
                    board[r][c] = 0;
                else
                    board[r][c] = 1;
            }
        }

//        setupMouse();
    }


    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;

//        public void setupMouse(){
//            addMouseListener(new MouseListener() {
//                @Override
//                public void mouseClicked(MouseEvent e) {
//
//                }
//
//                @Override
//                public void mousePressed(MouseEvent e) {
//                    int r = e.getY()/96;
//                    int c = e.getX()/96;
//                    board[r][c] = (board[r][c] + 1) % 2;
//                    repaint();
//                }
//
//                @Override
//                public void mouseReleased(MouseEvent e) {
//
//                }
//
//                @Override
//                public void mouseEntered(MouseEvent e) {
//
//                }
//
//                @Override
//                public void mouseExited(MouseEvent e) {
//
//                }
//            });
//        }



        int l = 96;
        for(int r = 0; r < board.length; r++){
            for(int c = 0; c < board[0].length; c++){
                if (board[r][c] == 0)
                    g2.setColor(Color.WHITE);
                else
                    g2.setColor(Color.BLACK);

                g2.fillRect((c * l), (r * l), l, l);

            }
        }


    }
}