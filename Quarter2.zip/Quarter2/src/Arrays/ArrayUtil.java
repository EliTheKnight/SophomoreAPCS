package Arrays;

public class ArrayUtil {

   //{6, 1, 2, 4, 6}
    public static void printArray(int[] arr){
        String out = "{";
        for (int i: arr){
            out += i + ", ";
        }
        out = out.substring(0, out.length() - 2);
        out += "}";
        System.out.println(out);
    }

    public static int getMaxIndex(int[] arr){
        int maxIndex = 0;
        for (int i = 0; i<arr.length; i++){
            if(arr[i] > arr[maxIndex])
                maxIndex = i;
        }
        return maxIndex;
    }

    public static int getMinIndex(int[] arr){
        int min = arr[0];
        int minIndex = 0;
        for (int i = 0; i<arr.length; i++){
            if(arr[i] < arr[minIndex])
                minIndex = i;
        }
        return minIndex;
    }

    //return array of random ints.
    //take in length, minValue, maxValue
    //the returned array will have length elements, each from [min, max]
    public static int[] getRandomArray(int length, int min, int max){
        int[] arr = new int[length];
        for(int i = 0; i < length; i++){
            arr[i] = (int)(Math.random()*(max-min+1) + min);
        }
        return arr;
    }


}
