import java.awt.*;

public class SodicksonMystery {
    
    private Point pointA, pointB, pointC;

    public SodicksonMystery(int pA1, int pA2, int pB1, int pB2, int pC1, int pC2){
        pointA = new Point(pA1,pA2);
        pointB = new Point(pB1,pB2);
        pointC = new Point(pC1,pC2);
    }

    public void draw(Graphics2D g2) {
        int currentX = 400;
        int currentY = 400;

        for (int i = 0; i < 1000000; i++) {

            int rand = (int) (Math.random() * 3) + 1 ;

            if (rand == 1) {
                currentX = (currentX + pointA.x) / 2;
                currentY = (currentY + pointA.y) / 2;
            } else if (rand == 2) {
                currentX = (currentX + pointB.x) / 2;
                currentY = (currentY + pointB.y) / 2;
            } else {
                currentX = (currentX + pointC.x) / 2;
                currentY = (currentY + pointC.y) / 2;
            }

            g2.drawLine(currentX,currentY,currentX+1, currentY+1);

        }
    }
}
