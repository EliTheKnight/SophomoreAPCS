public class LinearEquation {
    //this class won't have a main
    //most classes don't
    //this class will allow us to model and reuse a line, enable reusability
    //The class model system has 3 parts: instance fields, constructors, and methods.

    //class variables, instance fields, instance variables
    private double m;   //declared, byt no value assigned
    private double b;
    private double k;
    private double h;

    //constructor - purpose is to get instance fields their values.
    public LinearEquation(double m, double b){
        this.m = m;     //this.m is the instance field m - private thing above
        this.b = b;
    }

    public LinearEquation(double m, double k, double h) {
        this.m = m;
        this.h = h;
        this.k = k;
    }

    public double getY(double newX) {        //Public return type nameOfMethod
        //we MUST return a double
        double y = m * newX + b;
        return y;   //the "answer" or result of this method is the value of y
    }

    public void printPoint(double newX){
        double y = getY(newX);
        System.out.println("(" + newX + "," + y +")");
    }

    public double getPoint(double newX) {
        double y = m * (newX + k) + h;
        return y;
    }

    public void printXY(double newX){
        double y = getPoint(newX);
        System.out.println("(" + newX + "," + y +")");
    }



}
