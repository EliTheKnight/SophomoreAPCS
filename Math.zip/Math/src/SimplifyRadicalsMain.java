import java.util.Scanner;
public class SimplifyRadicalsMain {
    public static void main(String[] args) {

        System.out.println("enter the numerator beginning with the numbers in sq rts , followed by the denominator beginning with the numbers in sq rts");





    }
}
