import java.util.Scanner;

public class LinearMain {
    public static void main(String[] args) {

        //produce Y value on a line from x value
        // y = mx + b  --> m and b is constant that defines the line

//        double m = 2.;
//        double b = -4.;
//        // print y value for given x value
//        double x = 1;
//        double y =m*x+b;
//        System.out.println("y = " + y);

        //object -> a usable concrete created thing from the class blueprint
        //my ca : rav4 design :: object : class

        //user input/scanner version
        Scanner in = new Scanner (System.in);

        System.out.println("If you want Y intercept form enter 1, if you want point slope form, enter 2");
        int enter = in.nextInt();
        if (enter == 1) {

            System.out.println("enter the slope, the Y intercept, and the X value");

            LinearEquation equation = new LinearEquation(in.nextDouble(), in.nextDouble());
            equation.printPoint(in.nextDouble());
        }
        else if (enter == 2) {

            System.out.println("Enter the slope, an X coordinate, a Y coordinate, and the new X coordinate");
            LinearEquation equation2 = new LinearEquation(in.nextDouble(), in.nextDouble(), in.nextDouble());
            equation2.printXY(in.nextDouble());
        }


//
//        System.out.println();
//        LinearEquation line = new LinearEquation(-2,5);
//        line.printPoint(in.nextDouble());
//        line.printPoint(in.nextDouble());

//        line = equation;
//        line.printPoint(in.nextDouble());

            //NORMAL VERSION
//        LinearEquation equation = new LinearEquation(3, -2);
//        equation.printPoint(in.nextDouble());
//        equation.printPoint(3);
//
//        System.out.println();
//        LinearEquation line = new LinearEquation(-2,5);
//        line.printPoint(0);
//        line.printPoint(1);
//
//        line = equation;
//        line.printPoint(0);


//        LinearEquation equation2 = new LinearEquation(2, 3);
//        equation2.getY(5);
//
//        double ave = equation2.getY(5) + equation.getY(7)/2;
//        System.out.println(ave);


    }
}
