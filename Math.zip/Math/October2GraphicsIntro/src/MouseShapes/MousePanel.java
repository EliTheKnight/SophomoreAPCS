package MouseShapes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

public class MousePanel extends JPanel implements MouseListener {     //JPanels are things we draw on. Canvas?
    //MouseListener is an example of an "interface", is a collection of undefined methods
    //when a class implements an interface, the class must define those methods!

    private int x,y;
    private ArrayList<Point> points;

        public MousePanel(int width, int height) {
            setSize(width, height);
            addMouseListener(this);
            points = new ArrayList<>();
            x = -100;
            y = -100;

        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;  //g2 is out pen.

            for (int a = 0; a < points.size(); a++) {
                Point p = points.get(a);

                if (a % 3 == 0)
                    g2.setColor(Color.RED);
                else if (a % 3 == 1)
                    g2.setColor(Color.WHITE);
                else
                    g2.setColor(Color.BLUE);

                if (a % 2 == 0)
                g2.fillOval(p.x,p.y,50,50);
                else
                g2.fillRect(p.x,p.y,50,50);

            }
        }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {
        System.out.println(e);
        x = e.getX();
        y = e.getY();
        if(e.getButton() == 3)
            points.remove(points.size()-1);
        else
        points.add(new Point(e.getX(), e.getY()));
        repaint();
//        if(e.getButton() == MouseEvent.BUTTON3) //you can also replace MouseEvent.BUTTON3 with just  3
//            points.clear();       //clear all points


    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}
