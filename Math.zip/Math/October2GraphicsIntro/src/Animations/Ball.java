package Animations;

import javax.swing.*;
import java.awt.*;

public class Ball {

    private int x, y, radius, vx, vy;

    public Ball(int x, int y, int radius, int vx, int vy) {
        this.x = x;
        this.y = y;
        this.radius = radius;
        this.vx = vx;
        this.vy = vy;
    }

    public void move(int width, int height){
        x += vx;
        y += vy;

        if (x + radius * 2 >= width){
            vx *= -1;
            x = width - radius * 2;
        }

        if (x <= 0){
            vx *= -1;
            x = 0;
        }
        if (y + radius * 2 >= height){
            vy *= -1;
            y = height - radius * 2;
        }
        if (y <= 0){
            vy *= -1;
            y = 0;
        }


    }
    public int centerX(){
        int xCenter = x + radius;
        return xCenter;
    }

    public int centerY(){
        int yCenter = y + radius;
        return yCenter;
    }


    public boolean contains(int px, int py){
        // return( (px-centerX()) * (px-centerX()) + (py-centerY()) * (py-centerY()) <= radius*radius );
        if( (px-centerX()) * (px-centerX()) + (py-centerY()) * (py-centerY()) <= radius*radius )
            return true;
        else
            return false;
    }

    public void draw(Graphics2D g2){
        g2.fillOval(x, y, radius * 2, radius * 2);
    }

    public int getRadius() {
        return radius;
    }

}
