package CircleLists;

import java.awt.*;

public class Circle {

    /*
    Instance Fields:
        x and y, representing the top left corner of this Circle.
        radius - the radius of this circle
     */
    private int x, y, radius;

    //constructor that takes in (x, y, radius) and initializes them.

    public Circle(int x, int y, int radius) {
        this.x = x;
        this.y = y;
        this.radius = radius;
    }

    /*methods, commented out so no errors.  cmd /  to uncomment them when you are ready to code them.*/

    /*returns the x coordinate of the center of this circle.*/
    public int centerX(){
        int xCenter = x + radius;
        return xCenter;
    }

    /*returns the y coordinate of the center of this circle.*/
    public int centerY(){
        int yCenter = y + radius;
        return yCenter;
    }

    /*returns true if (px, py) is inside this Circle, false if (px, py) is not in this Circle.
    Mathematically, (px, py) is inside this circle if the distance from (px, py) to the center
    of this circle is less than the radius. */
    public boolean contains(int px, int py){
        // return( (px-centerX()) * (px-centerX()) + (py-centerY()) * (py-centerY()) <= radius*radius );
        if( (px-centerX()) * (px-centerX()) + (py-centerY()) * (py-centerY()) <= radius*radius )
            return true;
        else
            return false;
    }

    /*Fills an oval at (x, y) with width and height both equal to the radius*2. */
    public void draw(Graphics2D g2){
        g2.fillOval(x, y, radius * 2, radius * 2);
    }

    public int getRadius() {
        return radius;
    }

}
