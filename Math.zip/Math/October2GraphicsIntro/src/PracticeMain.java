public class PracticeMain {
    public static void main(String[] args) {
        String message = "";
        for(int i = 0; i < 6; i++)
            message = message + 2*i;
        System.out.println(message);
    }
}
