import java.sql.SQLOutput;

public class StringClass {
    public static void main(String[] args) {

        String word = "Computer Science";

//        word.substring()

        // e x a m p l e   -> "example"
        //0 1 2 3 4 5 6    -> substring(0,3) -> "exa"    substring(4) -> "ple"

//        word.equals()

        //word.equals(anotherString)    use instead of ==

//        word.indexOf()

        //word.indexOf(sub) returns the starting index of sub in word, -1 if not found
        word.indexOf("science"); //9
        word.indexOf("omp");  //1
        // if (word.indexOf(stringOther > 0)) word contains string other

//        word.compareTo()
        //"B" = 66, "A" = 65    "B">"A"
        String s1 = "cat";
        String s2 = "dog";
        System.out.println(s1.compareTo(s2));   //d>c dog>cat
        // < 0 -> s1 < s2
        // > 0 -> s1 > s2
        // ==0 -> s1 == s2

    }

}
