import java.awt.*;

public class Bullseye {
    private int x, y, size;

    public Bullseye(int x, int y, int size) {
        this.x = x;
        this.y = y;
        this.size = size;
    }

    public void draw (Graphics2D g2){
        g2.setColor(Color.RED);
        g2.fillOval(x,y,size,size);
        g2.setColor(Color.WHITE);
        g2.fillOval(x + size/10,y + size/10 ,size*4/5,size*4/5);
        g2.setColor(Color.RED);
        g2.fillOval(x + size*2/10,y + size*2/10 ,size*3/5,size*3/5);
        g2.setColor(Color.WHITE);
        g2.fillOval(x + size*3/10,y + size*3/10 ,size*2/5,size*2/5);
        g2.setColor(Color.RED);
        g2.fillOval(x + size*4/10,y + size*4/10 ,size/5,size/5);
    }

}
