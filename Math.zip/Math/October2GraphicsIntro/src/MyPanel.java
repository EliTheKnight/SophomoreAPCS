import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MyPanel extends JPanel{  //JPanels are things we draw on. Canvas?

    public MyPanel(int width, int height) {
        setSize(width, height);

    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D)g;  //g2 is out pen.


            for (int j = 0; j < 6; j++) {
                for (int i = 0; i < 4; i++) {
                    Bullseye hit = new Bullseye(80*j,80*i,80);
                    hit.draw(g2);

                }
            }


//        WitchFace boo = new WitchFace(200, 200, 200);
//        boo.draw(g2);


//        for(int i = 0; i < 8; i++) {
//            if(i%2 == 0) {
//                g2.drawRect(100 * i, 0, 100, 100);
//            }
//            else{
//                g2.fillRect(100 * i, 0, 100, 100);
//            }
//        }
        //Random Rectangles. 10 randomly located rects.
        //x is random from [0-800)
//        for(int i = 0; i < 1000; i++) {
//            int x = (int) (Math.random() * 800);
//            int y = (int) (Math.random() * 800);
//            Color myColor = new Color((int)(Math.random() * 255), (int)(Math.random() * 255), (int)(Math.random() * 255));   //r,g,b [0,255]
//            g.setColor(myColor);
//
//            int size = (int)(Math.random()*91)+10;
//            g2.fillRect(x,y,size,size);
//        }

        //do HW here:



//        Color custom1 = new Color(212, 30, 202);
//        Color custom2 = new Color(10, 199, 224);
//
//        RandomCircles circles = new RandomCircles(50, 20, Color.BLACK, Color.ORANGE);
//        circles.draw(g2);
//
//        RandomCircles circles2 = new RandomCircles(100, 75, custom1, custom2 );
//        circles2.draw(g2);
//        for(int i = 0; i < 10; i++){
//            int x = (int) (Math.random() * 800);
//            int y = (int) (Math.random() * 800);
////            SmileyFace smile1 = new SmileyFace(x,y);
////            smile1.draw(g2);
//            SmileyFace smile2 = new SmileyFace(i*100,0);
//            smile2.draw(g2);
//            SmileyFace smile3 = new SmileyFace(0, 100*i);
//            smile3.draw(g2);
//            SmileyFace smile4 = new SmileyFace(i*100,i*100);
//            smile4.draw(g2);
//
//        }

//        for (int j = 0; j<8; j++) {
//            for (int i = 0; i < 8; i++) {
//                SmileyFace aFace = new SmileyFace(i * 100, j * 100, 50);
//                aFace.draw(g2);
//            }
//        }

//        drawFaceGrid(16, g2);
//    }
//
//    /*
//    This will fill the screen with a numFaces x numFaces grid of faces.
//    The faces will be scaled so they will be tangent to each other.
//    */
//    public void drawFaceGrid(int numFaces, Graphics2D g2) {
//        for (int j = 0; j < numFaces; j++) {
//            for (int i = 0; i < numFaces; i++) {
//                int scaled = getHeight()/numFaces;
//                SmileyFace aFace = new SmileyFace(i * scaled, j * scaled, scaled);
//                aFace.draw(g2);
//            }
//        }
    }


}