import java.awt.*;

public class SmileyFace {

    protected int x, y, size;

    public SmileyFace(int x, int y, int size) {
        this.x = x;
        this.y = y;
        this.size = size;

    }

    public void draw(Graphics2D g2){
        g2.setColor(new Color(255, 212, 0, 255));
        g2.fillOval(x ,y , size, size);
        g2.setColor(Color.BLACK);
        int sized = size/5;
        g2.fillOval(x+sized, y+sized, sized, sized);
        g2.fillOval(x+3*sized, y+sized, sized, sized);
        g2.setColor(Color.BLACK);
        g2.fillArc(x+sized, y+sized, 3*sized, 3*sized, 180, 180);
    }


}
