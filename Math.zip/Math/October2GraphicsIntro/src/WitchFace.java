import java.awt.*;

public class WitchFace extends SmileyFace{
    public WitchFace(int x, int y, int size) {
        super(x, y, size);
    }

    @Override
    public void draw(Graphics2D g2) {
//        super.draw(g2);     //draws normal smileyface that we inherited.
//
//        g2.drawLine(x, y, x+size, y);
//
//        int[] xs = {x+size/5, x+size/2, x+size/5*4};
//        int[] ys = {y, y - size/3, y};
//        g2.fillPolygon(xs, ys, 3);

    }
}
