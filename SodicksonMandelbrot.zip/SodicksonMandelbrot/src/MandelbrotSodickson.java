public class MandelbrotSodickson {


}
