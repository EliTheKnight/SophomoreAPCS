public class MirrorImage extends CustomImage{

    public MirrorImage(String fileName, int x, int y) {
        super(fileName, x, y);
    }

    public MirrorImage(Pixel[][] pixels, int x, int y) {
        super(pixels, x, y);
    }


    @Override
    public void processImage(){
        Pixel[][] pixels = getPixels();
        Pixel[][] result = new Pixel[pixels.length][pixels[0].length];
        for (int r = 0; r < pixels.length; r++) {
            for (int c = 0; c < pixels[0].length; c++) {
                result[r][c] = pixels[r][pixels[0].length-c-1];
            }
        }
        setImage(result);
    }

}
