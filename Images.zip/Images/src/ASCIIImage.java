import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;

public class ASCIIImage extends CustomImage{

    private int x,y;

    public ASCIIImage(String fileName, int x, int y) {
        super(fileName, x, y);
        this.x = x;
        this.y = y;
    }

    public ASCIIImage(Pixel[][] pixels, int x, int y) {
        super(pixels, x, y);
        this.x = x;
        this.y = y;
    }


    @Override
    public void draw(Graphics2D g2){
        Pixel[][] pixels = getPixels();
        int pixelSize = 3;
        g2.setFont(new Font("RobotoMonaco", Font.PLAIN, 5));
        for (int r = 0; r< pixels.length; r+= pixelSize){
            for (int c = 0; c < pixels[0].length; c+= pixelSize) {

                int red = 0;
                int green = 0;
                int blue = 0;
                for (int pR = r; pR < r + pixelSize && pR < pixels.length; pR++) {
                    for (int pC = c; pC < c + pixelSize && pC < pixels[0].length; pC++) {
                        Pixel p = pixels[pR][pC];
                        red += p.getRed();
                        green += p.getGreen();
                        blue += p.getBlue();
                    }
                }
                Pixel a = pixels[r][c];
                double average = (red + green + blue)/(3*pixelSize*pixelSize);
                int s = c;
                int t = r;

                String characters = "$@B%8&WM#*oahkbdpqwmZO0QLCJUYXzcvunxrjft/\\|()1{}[]?-_+~<>i!lI;:,\"^`'.";
                characters = new StringBuilder(characters).reverse().toString();
                int ch = (int) (characters.length()*average/255) - 1;

                g2.drawString(characters.substring(ch,ch+1),x+s,y+t);

            }
        }
    }

}
