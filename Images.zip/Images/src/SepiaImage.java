public class SepiaImage extends CustomImage{

    public SepiaImage(String fileName, int x, int y) {
        super(fileName, x, y);
    }

    public SepiaImage(Pixel[][] pixels, int x, int y) {
        super(pixels, x, y);
    }


    @Override
    public void processImage(){
        Pixel[][] pixels = getPixels();
        for (int r = 0; r < pixels.length; r++) {
            for (int c = 0; c < pixels[0].length; c++) {
                Pixel p = pixels[r][c];
                int red = (int)((p.getRed() * .393) + (p.getGreen() *.769) + (p.getBlue() * .189));
                int green = (int)((p.getRed() * .349) + (p.getGreen() *.686) + (p.getBlue() * .168));
                int blue = (int)((p.getRed() * .272) + (p.getGreen() *.534) + (p.getBlue() * .131));
                if (red > 255)
                    red = 255;
                if (blue > 255)
                    blue = 255;
                if (green > 255)
                    green = 255;
                p.setColorRGB(red,green,blue);
            }
        }
        setImage(pixels);
    }

}
