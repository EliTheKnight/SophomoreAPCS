public class GrayScaleImage extends CustomImage{

    public GrayScaleImage(String fileName, int x, int y) {
        super(fileName, x, y);
    }

    public GrayScaleImage(Pixel[][] pixels, int x, int y) {
        super(pixels, x, y);
    }


    @Override
    public void processImage(){
        Pixel[][] pixels = getPixels();
        for (int r = 0; r < pixels.length; r++) {
            for (int c = 0; c < pixels[0].length; c++) {
                Pixel p = pixels[r][c];
                int a = (p.getBlue() + p.getGreen() + p.getRed())/3;
                p.setColorRGB(a,a,a);
            }
        }
        setImage(pixels);
    }

}
