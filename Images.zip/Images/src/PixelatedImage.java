public class PixelatedImage extends CustomImage{

    public PixelatedImage(String fileName, int x, int y) {
        super(fileName, x, y);
    }

    public PixelatedImage(Pixel[][] pixels, int x, int y) {
        super(pixels, x, y);
    }


    @Override
    public void processImage(){
        Pixel[][] pixels = getPixels();
        int pixelSize = 10;

        for (int r = 0; r < pixels.length; r+=pixelSize) {
            for (int c = 0; c < pixels[0].length; c+=pixelSize) {
                int red = 0;
                int green = 0;
                int blue = 0;
                for (int pR = r; pR<r+pixelSize && pR < pixels.length; pR++){
                    for (int pC = c; pC<c+pixelSize && pC<pixels[0].length; pC++){
                        Pixel p = pixels[pR][pC];
                        red+= p.getRed();
                        green+= p.getGreen();
                        blue+= p.getBlue();
                    }
                }

                for (int pR = r; pR<r+pixelSize && pR < pixels.length; pR++){
                    for (int pC = c; pC<c+pixelSize && pC<pixels[0].length; pC++){
                        Pixel p = pixels[pR][pC];
                        p.setColorRGB(red/(pixelSize*pixelSize),green/(pixelSize*pixelSize),blue/(pixelSize*pixelSize));
                    }
                }

            }
        }
        setImage(pixels);
    }

}
