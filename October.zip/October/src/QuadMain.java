public class QuadMain {
    public static void main(String[] args) {

        Quadratics func = new Quadratics (1,0,0);
        System.out.println(func.getNumSoluions());

        func.printRoots();
    }
}
