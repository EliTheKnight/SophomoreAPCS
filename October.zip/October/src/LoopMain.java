public class LoopMain {

        public static void main(String[] args) {
            Loops test = new Loops();
            test.forDemo();
        }

}
