import random

print ("hello world")

form = "my name is {}, I like {}, I am {} years old."
name = "\"Eli\""
food = "pizza"
age = "16"

a = 7
b = 6.4

y = "   HELLO   "
z = int ("5")

def first():
	global x
	x = "my first function"
	print (x)
	print ("!")

first()

print(b)
b = a + b 
print(b)
print (z)
print(x + "!")

print (type(x))

cow, cat, dog = "moo", "meow", "woof"

print (cow)
print (cat)
print (dog)

c = 2E4
print (c)

print (random.randrange(1,10))

print(y[1])

# for q in x:
# 	print (q)

for q in "ban":
	print (q)

txt = "the best things in life are free"

print ("free" in txt)
print ("apple" not in txt)

sub = x[1:6]
sub2 = x[:8]
sub3 = x[2:]
sub4 = x[-8:-2]
print (sub)
print (sub2)
print (sub3)
print (sub4)

print (y.upper())
print (y.lower())
print(y.strip())
print(y.replace("H", "A"))
print (y)
print (y.split("E"))

print (form.format(name,food,age))

print (bool(y))

# if b > a    if b < a     if b == a

print(b == a)

print (isinstance(x, float))

print (a**2)

a += 2
a /= 2

# use 	and, or, not, is
if a > 0 and a != b:
	a +=1

if a is b:
	a+=1

strList = ["apple", "orange", "cherry"]
thisList = list(("apple", "orange", "cherry"))
intList = [1,2,3]

print (strList)
print (intList)
t = len(strList)

crazyList = ["oh no", 5, True, False, 6.2563, "crazy"]

print(strList[2])

