package BallExtensions;

public class StairBall extends Ball{

    private int stepsTaken, stairSize, speed, step;
    public StairBall(int x, int y, int stairSize, int speed) {
        super(x, y, speed, speed);
        stepsTaken = 0;
        this.stairSize = stairSize;
        this.speed = speed;
        step = 1;
    }

    @Override
    public void move(int width, int height) {
        stepsTaken ++;
        if(stepsTaken >= stairSize){
            stepsTaken = 0;
            step *= -1 ;
        }
        if (step > 0) {
            setX(getX() + speed);
        }
        if (step < 0) {
            setY(getY() + speed);
        }
        handleEdges(width, height);
    }

    @Override
    public void handleEdges(int width, int height) {
        if(getX() + getSize() > width && speed > 0)
            speed*=-1;
        else if (getX() < 0 && speed < 0)
            speed*=-1;
        if (getY() + getSize() > height && speed > 0)
            speed*=-1;
        else if (getY() < 0 && speed <0)
            speed*=-1;
    }

}
