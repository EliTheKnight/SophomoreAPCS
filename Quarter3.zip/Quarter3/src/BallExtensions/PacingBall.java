package BallExtensions;

public class PacingBall extends Ball{
    //Ball is the SUPERCLASS of PacingBall  (PARENT CLASS)
    //PacingBall is the SUBCLASS of Ball    (CHILD CLASS)

    private int stepCounter, pathLength;

    public PacingBall(int x, int y, int vx, int vy, int pathLength) {
        super(x, y, vx, vy); //calling the Ball constructor
                //^^ must be first line of a subclass constructor
        this.pathLength = pathLength;
        stepCounter = 0;
    }

    //goal is to tweak the move method.. Override a method


    @Override
    public void move(int width, int height) {
        stepCounter++;
        if(stepCounter >= pathLength){
            setVx(-getVx());
            setVy(-getVy());
            stepCounter = 0;
        }
        super.move(width, height);
    }



}
