package BallExtensions;

public class PulseBall extends Ball{

    private int minSize, maxSize, grow;

    public PulseBall(int x, int y, int vx, int vy, int minSize, int maxSize) {
        super(x, y, vx, vy);
        this.maxSize = maxSize;
        this.minSize = minSize;
        grow = 1;
    }

    @Override
    public void move(int width, int height) {
        if (grow > 0){
            if (getSize() < maxSize) {
                setSize(getSize() + 1);
            }
            else{ grow *= -1; }
        }
        if (grow < 0) {
            if (getSize() > minSize){
                setSize(getSize() - 1);
            }
            else { grow *= -1; }
        }
        super.move(width, height);
    }
}
