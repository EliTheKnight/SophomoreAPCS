import java.awt.*;

public class ResultText {

    public void drawWin(Graphics2D g2){
//        g2.fillRect();
//        g2.fillRect();
//        g2.fillRect();
//        g2.fillRect();
//
//        g2.fillRect();
//        g2.fillRect();
//
//        g2.fillRect();
//        g2.fillRect();
//
//        g2.fillRect();
//        g2.fillRect();
//        g2.fillRect();
//        g2.fillRect();
//
//        g2.fillRect();
//        g2.fillRect();
//        g2.fillRect();
//
//        g2.fillRect();
//        g2.fillRect();
//        g2.drawLine();

          g2.drawString("YOU WIN", 250, 250);

    }

}
