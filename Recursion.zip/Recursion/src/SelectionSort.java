public class SelectionSort {


    /*
    Algorithm:
    Finds the min and swaps it to the front.
    Finds the next min and swaps it to the next spot...
    Forever...

    A note about efficiency...
    it's ALWAYS BigO ~ n^2 No matter the array. Always.
    It's really bad. Just don't use it ever.
     */
    public void sort(int[] arr){
        for(int i = 0; i < arr.length-1; i++){
            int mindex = findMin(i, arr);
            //swap mindex and i
            int temp = arr[i];
            arr[i] = arr[mindex];
            arr[mindex] = temp;
        }
    }


    //returns min value starting from from

    public int findMin(int from, int[] arr){
        int mindex = from;
        for (int i = from + 1; i < arr.length; i++) {
            if (arr[i] < arr[mindex]){
                mindex = i;
            }
        }
        return mindex;
    }

}
