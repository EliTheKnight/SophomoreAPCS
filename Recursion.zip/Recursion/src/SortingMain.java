public class SortingMain {
    public static void main(String[] args) {

        int[] test = {5,1,9,-1,0,3,7};
//        InsertionSorter insertionSorter = new InsertionSorter();
//        insertionSorter.sort(test);
//        for (Integer a: test)
//            System.out.print(a + " ");
//        System.out.println();


        SelectionSort selectionSort = new SelectionSort();
        selectionSort.sort(test);
        for (Integer a: test)
            System.out.print(a + " ");
        System.out.println();

    }
}
