public class RecursionIntro {

    public void badExample(){
        System.out.println("BAD"); // infinite recursion, stack overflow error
        badExample(); // recursive method call with no end condition
        System.out.println("done"); //will never print
    }


    public int factorial(int n){
        if (n==1){
            return 1;
        }
        else{
            return n * factorial(n-1);
        }
    }


    //return 1 + 2 + 3 ... + n
    public int sumFromOne(int n){
        if (n==1)
            return 1;

            return n + sumFromOne(n-1);
    }

    public int fibonacci(int n) {
        if(n==0) return 0;

        if(n==1) return 1;

        return fibonacci(n-1) + fibonacci(n-2);
    }


    public static void main(String[] args) {
        RecursionIntro obj = new RecursionIntro();
//        obj.badExample();

//        for (int i = 1; i<10; i++){
//            System.out.println(obj.factorial(i));
//        }

            System.out.println(obj.sumFromOne(100));

                System.out.println(obj.fibonacci(7));
    }
}
