public class GhostWall extends Wall{

    public GhostWall(int x, int y, int width, int height) {
        super(x, y, width, height);
    }
}
