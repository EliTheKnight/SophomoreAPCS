public class PlayerWall extends Wall{

    public PlayerWall(int x, int y, int width, int height) {
        super(x, y, width, height);
    }

}
