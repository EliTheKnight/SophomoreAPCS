public class PowerPellet extends Pellets{

    public PowerPellet(int x, int y) {
        super(x, y);
        setSize(7);
    }

}
