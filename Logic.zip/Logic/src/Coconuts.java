public class Coconuts {
    public static void main(String[] args) {

        int num = 10;
        boolean done = false;

        while (done == false){
            if (num % 10 == 9 && num % 9 == 8 && num % 8 == 7 &&num % 7 ==6 &&num % 6 ==5 &&num % 5 ==4 &&num % 4 ==3 &&num % 3 ==2 &&num % 2 ==1) {
                done = true;
            }
            else{
                num++;
            }
        }

        System.out.println(num);
    }
}
